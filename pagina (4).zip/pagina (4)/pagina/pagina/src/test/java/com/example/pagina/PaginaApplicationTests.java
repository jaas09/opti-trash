package com.example.pagina;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaginaApplicationTests {

	@Test
	void contextLoads() {
	}

}
