package com.example.pagina;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaginaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaginaApplication.class, args);
	}

}
